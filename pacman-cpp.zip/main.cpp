/******************************************************************************
    Game; Player Code
                        
*******************************************************************************/

#include <iostream>
#include <string>

using namespace std;

void StartScreen()
{
	system("cls");
	cout << "\nWELCOME TO PACMAN!"
	     << "\n\nHello, press 's' to Start!"
	     << "\n\nPress 'q' to Quit"
	     << "\n\nPress 'i' for Instructions."
    
    }
    
    void Instructions()
{
	system("cls");
	cout << "\nUse the 'w' key to go UP."
	     << "\n\nUse the 'a' key to turn LEFT."
	     << "\n\nUse the 's' key to go DOWN."
	     << "\n\nUse the 'd' key to turn RIGHT."
	     << "\n\nPress the 'x' key any time during the game to EXIT."

Class directions 

{

    public:
    
    }
    void input
    
    if (_kbhit())
    {
        switch (_getch())
        {
            case 'a';
                dir = LEFT;
                break;
            case 'd';
                dir = RIGHT;
                break;
            case 'w';
                dir = UP;
                break;
            case 's';
                dir = DOWN;
                break;
            case 'x';
                gameOver = true;
                break;
                
        }
        
int main()

{

    HANDLE  hConsole;

    int k =14;

 

    hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

    SetConsoleTextAttribute(hConsole, k);



    cout << "       ###############              "<< endl;        

    cout << "      ##################        "<< endl;      

    cout << "    #######################         "<< endl;        

    cout << "  ##############   ###########                  "<< endl;

    cout << "##############################                  "<< endl;

    cout << "#######################                 "<< endl;

    cout << "####################            "<< endl;

    cout << "################            "<< endl;

    cout << "#############               "<< endl;

    cout << "###########                 "<< endl;  

    cout << "#########                       "<< endl;

    cout << "############            "<< "PACMAN" << endl;        

    cout << "##################          "<< endl;      

    cout << "#######################         "<< endl;        

    cout << "###########################                 "<< endl;

    cout << "##############################                  "<< endl;

    cout << "    #######################                 "<< endl;

    cout << "      ####################              "<< endl;

    cout << "        ################            "<< endl;

 

    cout << endl;

    system("pause");

    char key = 0;

    system("mode 80, 50");

    int pills = 30;

    bool stopCounting  = false;

    //create the matrix
}

    class Ghost {

	public:
		Ghost(int type);
		int getGhostX();
		int getGhostY();
		int getGhostDirection();
		void changeGhostDirection(int newDirection);
        void changePosition(int changeX, int changeY);
		

	private:
		int x, y, direction;
		bool active, edible;

};


 endl   }
    
